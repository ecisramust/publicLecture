const API_URL = "http://localhost:3000/books";
 let editId = null;
const post = function(){

    
    const $form = document.getElementById('postReg');
    const formData = {};
    for (let i = 0; i < $form.elements.length; i++) {
            const element = $form.elements[i];

            if (element.name) {
                formData[element.name] = element.value;
            }
    }

    let bodie = JSON.stringify(formData);
    console.log(bodie);

    const method = editId ? "PUT" : "POST";
    const url = editId ? `${API_URL}/${editId}` : API_URL;
    const param = {
      method:method,
        hedears: {
            'Content-Type':'application/json'
        },
        body: bodie
   }
    
    const result =  fetch(url, param);
     alert(editId ? "Article updated!" : "Article added!");
    editId = null;
}


  

  function fetchPosts() {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", API_URL + "?_limit=5", true);
    xhr.onload = function () {
      const posts = JSON.parse(xhr.responseText);
      const list = document.getElementById("postList");
      list.innerHTML = ' ';
      posts.forEach(post => {
        list.innerHTML += `
          <tr>
            <td>${post.id}</td>
            <td>${post.product}</td>
            <td>${post.price}</td>
            <td>
              <button class="edit" onclick="edit('${post.id}', '${post.product.replace(/'/g, "\\'")}','${post.price.replace(/'/g, "\\'")}')">Edit</button>
              <button class="delete" onclick="deletePost('${post.id}')">Delete</button>
            </td>
          </tr>
        `;
      });
    };
    xhr.send();
  }


  function deletePost(id) {
    const xhr = new XMLHttpRequest();
    xhr.open("DELETE", `${API_URL}/${id}`, true);
    xhr.onload = function () {
      alert("Article deleted with id "+ id);
      fetchPosts();
    };
    xhr.send();
  }

  function edit(id, title,cost) {
    document.getElementById("product").value = title;
     document.getElementById("price").value = cost;
    editId = id;
  }
  fetchPosts();

 $(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#postList tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
