const API_URL = "http://localhost:3000/books";
 
const post = function(){

    
    const $form = document.getElementById('postReg');
    const formData = {};
    // console.log($form);
    //  console.log('enter to function');
    for (let i = 0; i < $form.elements.length; i++) {
            const element = $form.elements[i];

            if (element.name) {
                formData[element.name] = element.value;
            }
    }
  // console.log('transform ');
// tranform into json file
    let bodie = JSON.stringify(formData);
    console.log(bodie);

      // Use xhr better

   
    const param = {
      method:'POST',
        hedears: {
            'Content-Type':'application/json'
        },
        body: bodie
   }
    
    const result =  fetch(API_URL, param);
}


  let editId = null;

  function fetchPosts() {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", API_URL + "?_limit=5", true);
    xhr.onload = function () {
      const posts = JSON.parse(xhr.responseText);
      const list = document.getElementById("postList");
      list.innerHTML = ' ';
      posts.forEach(post => {
        list.innerHTML += `
          <tr>
            <td>${post.id}</td>
            <td>${post.product}</td>
            <td>
              <button class="edit" onclick="startEdit(${post.id}, '${post.product.replace(/'/g, "\\'")}')">Edit</button>
              <button class="delete" onclick="deletePost('${post.id})">Delete</button>
            </td>
          </tr>
        `;
      });
    };
    xhr.send();
  }

  fetchPosts();
